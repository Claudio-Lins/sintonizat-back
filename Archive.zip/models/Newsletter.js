const Sequelize = require('sequelize')
const db = require('./db')

const Newsletter = db.define('newsletter', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    allowNull: false,
    primaryKey: true,
  },
  email: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  name: {
    type: Sequelize.STRING,
    allowNull: false,
  }
})

// Newsletter.sync({ alter: true })

module.exports = Newsletter
 