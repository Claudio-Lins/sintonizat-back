const express = require('express')
const cors = require('cors')
const app = express()

const Newsletter = require('./models/Newsletter')

app.use(express.json())

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE')
  res.header(
    'Access-Control-Allow-Headers',
    'X-PINGOTHER, Content-Type, Authorization'
  )
  app.use(cors())
  next()
})

app.get('/newsletter', async (req, res) => {

  await Newsletter.findAll({
    attributes: ['id','name', 'email']
})
    .then((datanewsletter) => {
        return res.json({
            erro: false,
            datanewsletter
        });
    }).catch(() => {
        return res.status(400).json({
            erro: true,
            mensagem: "Erro: Nenhum valor encontrado para a página home!"
        });
    });
  // return res.json({
  //   error: false,
  //   newsletter: {
  //     name: 'Claudio F Lins',
  //     email: 'claudio.lins@me.com',
  //   },
  // })
})

app.post('/add-newsletter', async (req, res) => {
  console.log(req.body)

  await Newsletter.create(req.body)
    .then((newsletter) => {
      return res.json({
        error: false,
        mensagem: 'Cadastro enviado com Sucesso!',
      })
    })
    .catch(() => {
      return res.json({
        error: true,
        message: 'Erro ao salvar newsletter',
      })
    })
})

app.listen(8080, () => {
  console.log('Server running on port 8080')
})
